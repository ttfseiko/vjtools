#define REDIS_GIT_SHA1 "00000000"
#define REDIS_GIT_DIRTY "0"
#define REDIS_BUILD_ID "jabcofung-gz-web-5fqn6.vclound.com-1562925146"
